file_path<-""
setwd(file_path)

library(tidyverse)

ocorrencias_RJ<-read.csv("ocorrencias_rio_de_janeiro.csv")
ocorrencias_PE<-read.csv("ocorrencias_PE.csv")

RJ_events<-ocorrencias_RJ%>%select(latitude, longitude, date, policeAction, victims,
                                   state.name, city.name, neighborhood.name, 
                                   contextInfo.mainReason.name)%>%
  rename("state"=state.name, "city"=city.name, "neighborhood"=
           neighborhood.name, "context"=contextInfo.mainReason.name)%>%
  mutate(victims = if_else(victims == "[]", NA_real_, TRUE))%>%
  mutate(date = ymd_hms(date)) %>%  
  filter(date < ymd("2023-06-03"))


PE_events<-ocorrencias_PE%>%select(latitude, longitude, date, policeAction, victims,
                                   state.name, city.name, neighborhood.name, 
                                   contextInfo.mainReason.name)%>%
  rename("state"=state.name, "city"=city.name, "neighborhood"=
           neighborhood.name, "context"=contextInfo.mainReason.name)%>%
  mutate(victims = if_else(victims == "[]", NA_real_, TRUE))%>%
  mutate(date = ymd_hms(date)) %>% 
  filter(date < ymd("2022-06-03"))

gunshots<-bind_rows(RJ_events, PE_events)


file_path<-""
setwd(file_path)

write.csv(gunshots, "gunshots.csv")
